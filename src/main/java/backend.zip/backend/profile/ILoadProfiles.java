package backend.profile;

import org.json.JSONArray;

public interface ILoadProfiles {
    public JSONArray loadProfiles();
}