package backend.notifications;

import org.json.JSONObject;

public interface INotificationValid {
    boolean isRead(JSONObject notification);
}
