package backend.notifications;

import org.json.JSONArray;

public interface INM {
    public JSONArray getNotification(String author);
    void createNotifications(String id1, String id2);
}
