package backend.notifications;

import org.json.JSONObject;

public class NotificationValid implements INotificationValid {
    private final ILoadNotifications loadNotifications;
       private NotificationValid(ILoadNotifications loadNotifications) {
           this.loadNotifications = loadNotifications;
       }
      public boolean isRead(JSONObject notification){
           return true;
      }
}
