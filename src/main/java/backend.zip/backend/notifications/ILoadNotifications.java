package backend.notifications;

import org.json.JSONArray;

public interface ILoadNotifications {
   public  JSONArray LoadNotifications();
}
