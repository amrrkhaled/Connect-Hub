package backend.friendship;

import org.json.JSONArray;

public interface ILoadFriendShips {
    public JSONArray loadFriendships();
}
