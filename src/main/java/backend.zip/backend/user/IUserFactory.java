package backend.user;

public interface IUserFactory {
    UserManager createUserManager();
}
