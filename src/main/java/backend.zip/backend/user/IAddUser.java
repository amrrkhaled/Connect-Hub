package backend.user;

public interface IAddUser {
    public void addUser(String username, String password , String email , String dob);
}
