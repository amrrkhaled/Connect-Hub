package backend.user;

import org.json.JSONArray;

public interface ILoadUsers {
    public JSONArray loadUsers();
}
